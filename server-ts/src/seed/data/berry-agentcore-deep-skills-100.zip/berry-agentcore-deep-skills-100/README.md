# Berry AgentCore Deep Skills

100 narrow, production-oriented Agent Skills across 18 virtual IT-company roles.

Each skill contains:
- precise activation criteria
- a concrete required deliverable
- capability-specific checks
- evidence-first workflow
- verification requirements
- escalation boundaries
- capability-specific anti-patterns

The pack intentionally avoids duplicating AWS service-operation expertise that can be supplied
by Amazon Bedrock AgentCore's prebuilt AWS Skills.
